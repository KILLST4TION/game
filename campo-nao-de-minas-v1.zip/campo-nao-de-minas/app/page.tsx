"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

type Difficulty = "facil" | "medio" | "dificil";
type Cell = { mine: boolean; adjacent: number; revealed: boolean; flagged: boolean };
type GameStatus = "playing" | "won" | "lost";

const LEVELS: Record<Difficulty, { label: string; rows: number; cols: number; mines: number }> = {
  facil: { label: "Fácil", rows: 9, cols: 9, mines: 10 },
  medio: { label: "Médio", rows: 16, cols: 16, mines: 40 },
  dificil: { label: "Difícil", rows: 16, cols: 24, mines: 80 }
};

const NEIGHBORS = [
  [-1, -1], [-1, 0], [-1, 1], [0, -1],
  [0, 1], [1, -1], [1, 0], [1, 1]
];

function buildBoard(level: Difficulty): Cell[][] {
  const { rows, cols, mines } = LEVELS[level];
  const board: Cell[][] = Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => ({ mine: false, adjacent: 0, revealed: false, flagged: false }))
  );

  let placed = 0;
  while (placed < mines) {
    const r = Math.floor(Math.random() * rows);
    const c = Math.floor(Math.random() * cols);
    if (!board[r][c].mine) {
      board[r][c].mine = true;
      placed++;
    }
  }

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (board[r][c].mine) continue;
      board[r][c].adjacent = NEIGHBORS.reduce((sum, [dr, dc]) => {
        const nr = r + dr, nc = c + dc;
        return sum + (board[nr]?.[nc]?.mine ? 1 : 0);
      }, 0);
    }
  }
  return board;
}

function revealArea(source: Cell[][], startR: number, startC: number): Cell[][] {
  const board = source.map(row => row.map(cell => ({ ...cell })));
  const queue: [number, number][] = [[startR, startC]];
  const seen = new Set<string>();

  while (queue.length) {
    const [r, c] = queue.shift()!;
    const key = `${r},${c}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const cell = board[r]?.[c];
    if (!cell || cell.revealed || cell.flagged || cell.mine) continue;
    cell.revealed = true;
    if (cell.adjacent === 0) {
      for (const [dr, dc] of NEIGHBORS) {
        const nr = r + dr, nc = c + dc;
        if (board[nr]?.[nc] && !board[nr][nc].revealed) queue.push([nr, nc]);
      }
    }
  }
  return board;
}

export default function Home() {
  const [difficulty, setDifficulty] = useState<Difficulty>("facil");
  const [board, setBoard] = useState<Cell[][]>(() => buildBoard("facil"));
  const [status, setStatus] = useState<GameStatus>("playing");
  const [flags, setFlags] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [best, setBest] = useState<Record<Difficulty, number | null>>({ facil: null, medio: null, dificil: null });
  const [sound, setSound] = useState(false);

  const config = LEVELS[difficulty];
  const revealedCount = useMemo(() => board.flat().filter(c => c.revealed && !c.mine).length, [board]);
  const safeTotal = config.rows * config.cols - config.mines;

  useEffect(() => {
    const saved: Record<Difficulty, number | null> = {
      facil: Number(localStorage.getItem("cnm-best-facil")) || null,
      medio: Number(localStorage.getItem("cnm-best-medio")) || null,
      dificil: Number(localStorage.getItem("cnm-best-dificil")) || null
    };
    setBest(saved);
  }, []);

  useEffect(() => {
    if (status !== "playing") return;
    const timer = window.setInterval(() => setSeconds(s => s + 1), 1000);
    return () => window.clearInterval(timer);
  }, [status, board]);

  const newGame = useCallback((level: Difficulty = difficulty) => {
    setDifficulty(level);
    setBoard(buildBoard(level));
    setStatus("playing");
    setFlags(0);
    setSeconds(0);
  }, [difficulty]);

  const finishWin = useCallback((next: Cell[][]) => {
    const cleared = next.flat().filter(c => c.revealed && !c.mine).length;
    const totalSafe = config.rows * config.cols - config.mines;
    if (cleared === totalSafe) {
      setStatus("won");
      setBest(prev => {
        const old = prev[difficulty];
        const updated = old === null || seconds < old ? seconds : old;
        if (updated !== old) localStorage.setItem(`cnm-best-${difficulty}`, String(updated));
        return { ...prev, [difficulty]: updated };
      });
    }
  }, [config.cols, config.mines, config.rows, difficulty, seconds]);

  const reveal = (r: number, c: number) => {
    if (status !== "playing") return;
    const cell = board[r][c];
    if (cell.revealed || cell.flagged) return;

    if (cell.mine) {
      const lost = board.map(row => row.map(item => ({ ...item })));
      lost[r][c].revealed = true;
      lost.forEach(row => row.forEach(item => { if (item.mine) item.revealed = true; }));
      setBoard(lost);
      setStatus("lost");
      return;
    }

    const next = revealArea(board, r, c);
    setBoard(next);
    finishWin(next);
  };

  const toggleFlag = (event: React.MouseEvent, r: number, c: number) => {
    event.preventDefault();
    if (status !== "playing") return;
    const cell = board[r][c];
    if (cell.revealed) return;
    const next = board.map(row => row.map(item => ({ ...item })));
    next[r][c].flagged = !next[r][c].flagged;
    setFlags(next.flat().filter(item => item.flagged).length);
    setBoard(next);
  };

  const formatTime = (value: number) => `${Math.floor(value / 60).toString().padStart(2, "0")}:${(value % 60).toString().padStart(2, "0")}`;

  return (
    <main className="page-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar">
        <a className="brand" href="#" aria-label="Campo Não de Minas">
          <span className="brand-mark">✳</span>
          <span>CAMPO <b>NÃO</b> DE MINAS</span>
        </a>
        <div className="top-tag"><span className="live-dot" /> MINESWEEPER / WEB</div>
      </header>

      <section className="hero">
        <div className="eyebrow"><span /> OPERAÇÃO: NÃO EXPLODA</div>
        <h1>CAMPO NÃO <span>DE MINAS.</span></h1>
        <p className="subtitle">Pense rápido. Marque as suspeitas. Encontre o caminho seguro.</p>
      </section>

      <section className="game-layout">
        <div className="board-panel">
          <div className="board-heading">
            <div>
              <div className="panel-kicker">ÁREA DE OPERAÇÃO</div>
              <h2>Setor <span>01</span></h2>
            </div>
            <div className="board-state"><span className={status === "playing" ? "status-dot" : status === "won" ? "status-dot won" : "status-dot lost"} />{status === "playing" ? "EM ANDAMENTO" : status === "won" ? "SETOR LIMPO" : "BOOM! FIM DE JOGO"}</div>
          </div>

          <div className="stats-row">
            <div className="stat-card"><span className="stat-icon bomb-icon">✹</span><div><small>MINAS</small><strong>{Math.max(0, config.mines - flags).toString().padStart(2, "0")}</strong></div></div>
            <div className="stat-card"><span className="stat-icon flag-icon">⚑</span><div><small>BANDEIRAS</small><strong>{flags.toString().padStart(2, "0")}</strong></div></div>
            <div className="stat-card"><span className="stat-icon time-icon">◷</span><div><small>TEMPO</small><strong>{formatTime(seconds)}</strong></div></div>
          </div>

          <div className={`board-wrap ${difficulty}`}>
            <div className="board" style={{ gridTemplateColumns: `repeat(${config.cols}, minmax(0, 1fr))` }}>
              {board.map((row, r) => row.map((cell, c) => (
                <button
                  key={`${r}-${c}`}
                  className={`cell ${cell.revealed ? "revealed" : ""} ${cell.mine && cell.revealed ? "mine-cell" : ""} ${cell.flagged ? "flagged" : ""}`}
                  onClick={() => reveal(r, c)}
                  onContextMenu={event => toggleFlag(event, r, c)}
                  aria-label={`Linha ${r + 1}, coluna ${c + 1}${cell.revealed ? cell.mine ? ", mina" : `, ${cell.adjacent} minas próximas` : ", escondida"}`}
                  disabled={status !== "playing" && !cell.mine}
                >
                  {cell.flagged && !cell.revealed ? <span className="flag">⚑</span> :
                    cell.revealed && cell.mine ? <span className="mine">✹</span> :
                    cell.revealed && cell.adjacent > 0 ? <span className={`number n${cell.adjacent}`}>{cell.adjacent}</span> : null}
                </button>
              )))}
            </div>
          </div>

          {status !== "playing" && (
            <div className={`result-banner ${status}`}>
              <span className="result-symbol">{status === "won" ? "✦" : "✹"}</span>
              <div><strong>{status === "won" ? "SETOR DESARMADO!" : "VOCÊ PISOU NA MINA!"}</strong><small>{status === "won" ? `Mandou bem! Você limpou o campo em ${formatTime(seconds)}.` : "Não foi dessa vez. Respire fundo e tente novamente."}</small></div>
              <button onClick={() => newGame()} className="result-retry">JOGAR DE NOVO ↗</button>
            </div>
          )}

          <div className="board-footer"><span>CLIQUE DIREITO PARA MARCAR UMA MINA</span><span>{revealedCount}/{safeTotal} CASAS SEGURAS</span></div>
        </div>

        <aside className="side-panel">
          <div className="side-card difficulty-card">
            <div className="panel-kicker">CONFIGURAÇÃO</div>
            <h3>Nível de risco</h3>
            <div className="difficulty-options">
              {(Object.keys(LEVELS) as Difficulty[]).map(level => (
                <button key={level} onClick={() => newGame(level)} className={`difficulty-button ${difficulty === level ? "active" : ""}`}>
                  <span>{LEVELS[level].label}</span><small>{LEVELS[level].rows} × {LEVELS[level].cols}</small>
                </button>
              ))}
            </div>
            <div className="level-detail"><span>MINAS NO CAMPO</span><strong>{config.mines}</strong></div>
          </div>

          <div className="side-card record-card">
            <div className="panel-kicker">SEU DESEMPENHO</div>
            <h3>Melhor tempo</h3>
            <div className="record-time">{best[difficulty] === null ? "--:--" : formatTime(best[difficulty]!)}</div>
            <p>Seu recorde fica salvo neste navegador.</p>
          </div>

          <div className="side-card howto-card">
            <div className="panel-kicker">MANUAL DE CAMPO</div>
            <h3>Como jogar</h3>
            <div className="instruction"><span className="instruction-key">01</span><p><b>Revele</b> uma casa com o clique esquerdo.</p></div>
            <div className="instruction"><span className="instruction-key">02</span><p><b>Marque</b> uma possível mina com o clique direito.</p></div>
            <div className="instruction"><span className="instruction-key">03</span><p><b>Use os números</b> para descobrir quantas minas existem ao redor.</p></div>
            <div className="tip-box"><span>⚡ DICA</span> Casas vazias revelam automaticamente uma área segura ao redor.</div>
          </div>

          <button className="new-game-button" onClick={() => newGame()}>↻ <span>NOVO JOGO</span></button>
          <button className="sound-toggle" onClick={() => setSound(s => !s)}><span>{sound ? "◖))" : "♪"}</span> EFEITOS SONOROS <b>{sound ? "ON" : "OFF"}</b><small>Em breve</small></button>
        </aside>
      </section>

      <footer className="footer"><span>CAMPO NÃO DE MINAS <i>•</i> VERSÃO 1.0</span><span>FEITO PARA QUEM GOSTA DE VIVER PERIGOSAMENTE.</span></footer>
    </main>
  );
}
