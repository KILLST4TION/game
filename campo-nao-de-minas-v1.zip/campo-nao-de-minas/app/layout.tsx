import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Campo Não de Minas",
  description: "Um campo minado neon. Encontre as casas seguras e não exploda!",
  applicationName: "Campo Não de Minas"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
