# Campo Não de Minas

Jogo Campo Minado em Next.js, com interface neon e layout responsivo.

## Requisitos
- Node.js 20.9 ou superior
- npm

## Rodar localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000.

## Controles
- Clique esquerdo: revelar uma casa.
- Clique direito: colocar/remover bandeira.
- Escolha Fácil, Médio ou Difícil para iniciar uma nova partida.

## Publicar na Vercel
1. Crie um repositório no GitHub e envie os arquivos deste projeto.
2. Entre em https://vercel.com e importe o repositório.
3. Mantenha as configurações padrão do Next.js.
4. Clique em Deploy.

Não é necessário configurar banco de dados. O recorde é salvo localmente no navegador de cada jogador.

## Observações da V1
- O tabuleiro e as minas são gerados no navegador.
- Os recordes ficam no `localStorage` do navegador.
- O botão de efeitos sonoros é apenas visual nesta versão; áudio pode ser adicionado em uma próxima versão.
